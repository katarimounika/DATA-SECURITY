import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

// Create a client
const queryClient = new QueryClient();

function AnalyzeContent() {
  const { data: user, loading: userLoading } = useUser();
  const [inputData, setInputData] = useState("");
  const [sourceType, setSourceType] = useState("email");
  const [results, setResults] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const queryClientInstance = useQueryClient();

  // Analyze threat mutation
  const analyzeMutation = useMutation({
    mutationFn: async ({ input_data, source_type }) => {
      const response = await fetch("/api/detect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input_data, source_type }),
      });
      if (!response.ok) {
        throw new Error("Failed to analyze content");
      }
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      queryClientInstance.invalidateQueries({ queryKey: ["threats"] });
      queryClientInstance.invalidateQueries({ queryKey: ["alerts"] });
    },
    onError: (error) => {
      console.error("Analysis error:", error);
    },
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!userLoading && !user) {
      if (typeof window !== "undefined") {
        window.location.href = "/account/signin";
      }
    }
  }, [user, userLoading]);

  const handleAnalyze = async (e) => {
    e.preventDefault();
    if (!inputData.trim()) return;

    setResults(null);
    setIsAnalyzing(true);

    try {
      await analyzeMutation.mutateAsync({
        input_data: inputData,
        source_type: sourceType,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getThreatLevelColor = (level) => {
    switch (level) {
      case "critical":
        return "bg-red-600 text-white";
      case "high":
        return "bg-red-500 text-white";
      case "medium":
        return "bg-yellow-500 text-white";
      case "low":
        return "bg-green-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const exampleInputs = {
    email:
      "URGENT: Your account has been suspended! Click here to verify your login credentials immediately or your account will be permanently deleted.",
    file: "suspicious_document.exe - This file contains malware and trojan viruses that will infect your system.",
    url: "http://bit.ly/suspicious-phishing-site-login-steal-credentials",
    network:
      "Unauthorized access attempt detected from unknown IP address trying to breach security protocols.",
  };

  if (userLoading || !user) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-red-50 to-orange-50">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <button
                onClick={() => {
                  if (typeof window !== "undefined") {
                    window.location.href = "/dashboard";
                  }
                }}
                className="mr-4 text-gray-600 hover:text-gray-900"
              >
                ← Back to Dashboard
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  AI Threat Analysis
                </h1>
                <p className="text-gray-600">
                  Test our AI detection system with your content
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                if (typeof window !== "undefined") {
                  window.location.href = "/account/logout";
                }
              }}
              className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Analysis Form */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">
            Analyze Content for Threats
          </h2>

          <form onSubmit={handleAnalyze} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Source Type
              </label>
              <select
                value={sourceType}
                onChange={(e) => setSourceType(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="email">Email Content</option>
                <option value="file">File Content</option>
                <option value="url">URL/Link</option>
                <option value="network">Network Traffic</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Content to Analyze
              </label>
              <textarea
                value={inputData}
                onChange={(e) => setInputData(e.target.value)}
                placeholder={`Enter ${sourceType} content to analyze for threats...`}
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
              <div className="mt-2">
                <button
                  type="button"
                  onClick={() => setInputData(exampleInputs[sourceType])}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  Use example {sourceType} content
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={!inputData.trim() || isAnalyzing}
              className="w-full bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyzing with AI...
                </div>
              ) : (
                "Analyze for Threats"
              )}
            </button>
          </form>
        </div>

        {/* Analysis Results */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Analysis Summary
              </h3>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">
                    {results.threats_detected}
                  </div>
                  <div className="text-sm text-gray-600">Threats Detected</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">
                    {results.processing_time.toFixed(2)}s
                  </div>
                  <div className="text-sm text-gray-600">Processing Time</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">
                    {results.analysis_summary.max_confidence.toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600">Max Confidence</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {results.analysis_summary.critical_threats +
                      results.analysis_summary.high_threats}
                  </div>
                  <div className="text-sm text-gray-600">High Risk</div>
                </div>
              </div>

              {results.threats_detected === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <svg
                      className="w-8 h-8 text-green-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">
                    No Threats Detected
                  </h4>
                  <p className="text-gray-600">
                    The content appears to be safe based on our AI analysis.
                  </p>
                </div>
              ) : (
                <div className="text-center py-4">
                  <div className="w-16 h-16 bg-red-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <svg
                      className="w-8 h-8 text-red-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                      />
                    </svg>
                  </div>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">
                    {results.analysis_summary.critical_threats > 0
                      ? "DANGER!! CRITICAL THREATS DETECTED"
                      : "Threats Detected"}
                  </h4>
                  <p className="text-gray-600">
                    Our AI has identified potential security threats in the
                    content.
                  </p>
                </div>
              )}
            </div>

            {/* Detailed Results */}
            {results.threats.length > 0 && (
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">
                    Detected Threats
                  </h3>
                </div>
                <div className="divide-y divide-gray-200">
                  {results.threats.map((threat, index) => (
                    <div key={threat.id || index} className="px-6 py-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getThreatLevelColor(threat.threat_level)}`}
                            >
                              {threat.threat_level.toUpperCase()}
                            </span>
                            <h4 className="ml-3 text-lg font-medium text-gray-900">
                              {threat.threat_type}
                            </h4>
                          </div>
                          <p className="text-gray-600 mb-2">
                            {threat.description}
                          </p>
                          <div className="text-sm text-gray-500">
                            <span>
                              Confidence: {threat.confidence_score.toFixed(1)}%
                            </span>
                            <span className="mx-2">•</span>
                            <span>Source: {threat.source_type}</span>
                            <span className="mx-2">•</span>
                            <span>
                              Detected:{" "}
                              {new Date(threat.detected_at).toLocaleString()}
                            </span>
                          </div>
                          {threat.metadata?.matched_keywords &&
                            threat.metadata.matched_keywords.length > 0 && (
                              <div className="mt-2">
                                <span className="text-sm text-gray-500">
                                  Suspicious keywords:{" "}
                                </span>
                                {threat.metadata.matched_keywords.map(
                                  (keyword, i) => (
                                    <span
                                      key={i}
                                      className="inline-block bg-red-100 text-red-800 text-xs px-2 py-1 rounded mr-1"
                                    >
                                      {keyword}
                                    </span>
                                  ),
                                )}
                              </div>
                            )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Performance Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg
                    className="h-5 w-5 text-blue-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-blue-800">
                    AI Analysis Complete
                  </h3>
                  <div className="mt-2 text-sm text-blue-700">
                    <p>
                      Analysis completed in {results.processing_time.toFixed(2)}{" "}
                      seconds.
                      {results.threats_detected > 0 && (
                        <span>
                          {" "}
                          Alerts have been generated for high-risk threats and
                          saved to your dashboard.
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Help Section */}
        <div className="bg-gray-100 rounded-lg p-6 mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            How It Works
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">
                AI Detection Process
              </h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Content is analyzed using advanced AI algorithms</li>
                <li>• Multiple threat patterns are checked simultaneously</li>
                <li>
                  • Confidence scores are calculated based on risk indicators
                </li>
                <li>• Results are generated in under 3 seconds</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">
                Threat Categories
              </h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>
                  • <span className="font-medium text-red-600">Critical:</span>{" "}
                  Immediate action required
                </li>
                <li>
                  • <span className="font-medium text-red-500">High:</span>{" "}
                  Significant security risk
                </li>
                <li>
                  • <span className="font-medium text-yellow-600">Medium:</span>{" "}
                  Potential threat detected
                </li>
                <li>
                  • <span className="font-medium text-green-600">Low:</span>{" "}
                  Minor suspicious activity
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AnalyzePage() {
  return (
    <QueryClientProvider client={queryClient}>
      <AnalyzeContent />
    </QueryClientProvider>
  );
}
