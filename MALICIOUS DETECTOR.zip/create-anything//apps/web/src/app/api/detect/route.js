import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Simulated AI threat detection function
function simulateAIDetection(inputData, sourceType) {
  const threats = [
    {
      type: "Phishing Email",
      keywords: [
        "urgent",
        "verify",
        "account",
        "suspended",
        "click here",
        "login",
        "password",
      ],
      baseConfidence: 85,
      level: "high",
    },
    {
      type: "Malware",
      keywords: ["exe", "download", "install", "virus", "trojan", "infected"],
      baseConfidence: 92,
      level: "critical",
    },
    {
      type: "Suspicious URL",
      keywords: ["bit.ly", "tinyurl", "suspicious", "malicious", "phishing"],
      baseConfidence: 78,
      level: "medium",
    },
    {
      type: "Data Exfiltration",
      keywords: ["large", "transfer", "export", "download", "sensitive"],
      baseConfidence: 88,
      level: "high",
    },
    {
      type: "Network Intrusion",
      keywords: ["unauthorized", "access", "breach", "intrusion", "attack"],
      baseConfidence: 94,
      level: "critical",
    },
  ];

  const inputLower = inputData.toLowerCase();
  let detectedThreats = [];

  for (const threat of threats) {
    const matchedKeywords = threat.keywords.filter((keyword) =>
      inputLower.includes(keyword.toLowerCase()),
    );

    if (matchedKeywords.length > 0) {
      const confidence = Math.min(
        threat.baseConfidence + matchedKeywords.length * 5,
        99.9,
      );

      // Add some randomness to make it more realistic
      const finalConfidence = confidence + (Math.random() * 4 - 2);

      detectedThreats.push({
        threat_type: threat.type,
        threat_level: threat.level,
        confidence_score: Math.max(85, Math.min(99.9, finalConfidence)),
        matched_keywords: matchedKeywords,
        description: `Detected ${threat.type.toLowerCase()} with ${matchedKeywords.length} suspicious indicators`,
      });
    }
  }

  // If no specific threats detected but input seems suspicious
  if (detectedThreats.length === 0 && inputData.length > 10) {
    const suspiciousWords = [
      "free",
      "win",
      "prize",
      "congratulations",
      "limited time",
    ];
    const hasSuspicious = suspiciousWords.some((word) =>
      inputLower.includes(word.toLowerCase()),
    );

    if (hasSuspicious) {
      detectedThreats.push({
        threat_type: "Suspicious Content",
        threat_level: "low",
        confidence_score: 65 + Math.random() * 15,
        matched_keywords: [],
        description:
          "Content contains potentially suspicious language patterns",
      });
    }
  }

  return detectedThreats;
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { input_data, source_type } = body;

    // Validate required fields
    if (!input_data || !source_type) {
      return Response.json(
        {
          error: "Missing required fields: input_data, source_type",
        },
        { status: 400 },
      );
    }

    // Validate source_type
    const validSources = ["email", "file", "url", "network"];
    if (!validSources.includes(source_type)) {
      return Response.json(
        {
          error:
            "Invalid source_type. Must be one of: " + validSources.join(", "),
        },
        { status: 400 },
      );
    }

    // Simulate AI processing time (1-3 seconds)
    const processingTime = 1000 + Math.random() * 2000;
    await new Promise((resolve) => setTimeout(resolve, processingTime));

    // Run AI detection simulation
    const detectedThreats = simulateAIDetection(input_data, source_type);

    const results = [];

    // Store detected threats in database
    for (const threat of detectedThreats) {
      const result = await sql`
        INSERT INTO threat_detections 
        (user_id, threat_type, threat_level, confidence_score, source_data, source_type, description, metadata)
        VALUES (${userId}, ${threat.threat_type}, ${threat.threat_level}, ${threat.confidence_score}, ${input_data}, ${source_type}, ${threat.description}, ${JSON.stringify({ matched_keywords: threat.matched_keywords })})
        RETURNING id, threat_type, threat_level, confidence_score, source_data, source_type, status, description, metadata, detected_at
      `;

      const savedThreat = result[0];
      results.push(savedThreat);

      // Create alert for high/critical threats
      if (
        threat.threat_level === "high" ||
        threat.threat_level === "critical"
      ) {
        await sql`
          INSERT INTO alerts (user_id, threat_detection_id, alert_type, title, message, severity)
          VALUES (${userId}, ${savedThreat.id}, 'threat_detection', 
                  ${"DANGER!! IT CONTAINS MALICIOUS DATA"}, 
                  ${"DANGER!! " + (threat.threat_level === "critical" ? "CRITICAL THREAT DETECTED" : "HIGH THREAT DETECTED") + "\n\nThreat Type: " + threat.threat_type + "\nConfidence: " + threat.confidence_score.toFixed(1) + "%\nLevel: " + threat.threat_level.toUpperCase() + "\n\nImmediate action recommended. This content has been flagged as malicious and stored in alerts for review."}, 
                  ${threat.threat_level === "critical" ? "critical" : "danger"})
        `;
      }
    }

    // Record performance metrics
    await sql`
      INSERT INTO performance_metrics (metric_type, metric_value, unit)
      VALUES ('detection_speed', ${processingTime / 1000}, 'seconds')
    `;

    const response = {
      processing_time: processingTime / 1000,
      threats_detected: results.length,
      threats: results,
      analysis_summary: {
        total_threats: results.length,
        critical_threats: results.filter((t) => t.threat_level === "critical")
          .length,
        high_threats: results.filter((t) => t.threat_level === "high").length,
        medium_threats: results.filter((t) => t.threat_level === "medium")
          .length,
        low_threats: results.filter((t) => t.threat_level === "low").length,
        max_confidence:
          results.length > 0
            ? Math.max(...results.map((t) => t.confidence_score))
            : 0,
      },
    };

    return Response.json(response, { status: 201 });
  } catch (err) {
    console.error("POST /api/detect error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
