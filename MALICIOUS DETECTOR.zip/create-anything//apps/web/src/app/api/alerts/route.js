import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get("limit")) || 20;
    const offset = parseInt(url.searchParams.get("offset")) || 0;
    const unreadOnly = url.searchParams.get("unread_only") === "true";

    let whereClause = "WHERE a.user_id = $1";
    let params = [userId];

    if (unreadOnly) {
      whereClause += " AND a.is_read = false";
    }

    const query = `
      SELECT a.id, a.alert_type, a.title, a.message, a.severity, 
             a.is_read, a.is_dismissed, a.created_at,
             t.id as threat_id, t.threat_type, t.threat_level
      FROM alerts a
      LEFT JOIN threat_detections t ON a.threat_detection_id = t.id
      ${whereClause}
      ORDER BY a.created_at DESC 
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;

    params.push(limit, offset);
    const alerts = await sql(query, params);

    // Get total count
    const countQuery = `SELECT COUNT(*) as total FROM alerts a ${whereClause}`;
    const countResult = await sql(countQuery, params.slice(0, -2));
    const total = parseInt(countResult[0]?.total || 0);

    return Response.json({ alerts, total, limit, offset });
  } catch (err) {
    console.error("GET /api/alerts error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { alert_type, title, message, severity, threat_detection_id } = body;

    // Validate required fields
    if (!alert_type || !title || !message || !severity) {
      return Response.json(
        {
          error:
            "Missing required fields: alert_type, title, message, severity",
        },
        { status: 400 },
      );
    }

    // Validate severity
    const validSeverities = ["info", "warning", "danger", "critical"];
    if (!validSeverities.includes(severity)) {
      return Response.json(
        {
          error:
            "Invalid severity. Must be one of: " + validSeverities.join(", "),
        },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO alerts (user_id, threat_detection_id, alert_type, title, message, severity)
      VALUES (${userId}, ${threat_detection_id || null}, ${alert_type}, ${title}, ${message}, ${severity})
      RETURNING id, alert_type, title, message, severity, is_read, is_dismissed, created_at
    `;

    return Response.json({ alert: result[0] }, { status: 201 });
  } catch (err) {
    console.error("POST /api/alerts error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
