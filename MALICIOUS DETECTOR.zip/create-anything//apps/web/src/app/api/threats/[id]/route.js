import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const threatId = params.id;

    const threats = await sql`
      SELECT id, threat_type, threat_level, confidence_score, source_data, 
             source_type, status, description, metadata, detected_at, resolved_at
      FROM threat_detections 
      WHERE id = ${threatId} AND user_id = ${userId}
      LIMIT 1
    `;

    if (threats.length === 0) {
      return Response.json({ error: "Threat not found" }, { status: 404 });
    }

    return Response.json({ threat: threats[0] });
  } catch (err) {
    console.error("GET /api/threats/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const threatId = params.id;
    const body = await request.json();
    const { status, description } = body;

    // Validate status if provided
    if (status) {
      const validStatuses = [
        "detected",
        "investigating",
        "resolved",
        "false_positive",
      ];
      if (!validStatuses.includes(status)) {
        return Response.json(
          {
            error:
              "Invalid status. Must be one of: " + validStatuses.join(", "),
          },
          { status: 400 },
        );
      }
    }

    const setClauses = [];
    const values = [];

    if (status) {
      setClauses.push("status = $" + (values.length + 1));
      values.push(status);

      // Set resolved_at if status is resolved or false_positive
      if (status === "resolved" || status === "false_positive") {
        setClauses.push("resolved_at = NOW()");
      } else {
        setClauses.push("resolved_at = NULL");
      }
    }

    if (description !== undefined) {
      setClauses.push("description = $" + (values.length + 1));
      values.push(description);
    }

    if (setClauses.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    const query = `
      UPDATE threat_detections 
      SET ${setClauses.join(", ")}
      WHERE id = $${values.length + 1} AND user_id = $${values.length + 2}
      RETURNING id, threat_type, threat_level, confidence_score, source_data, 
                source_type, status, description, metadata, detected_at, resolved_at
    `;

    const result = await sql(query, [...values, threatId, userId]);

    if (result.length === 0) {
      return Response.json({ error: "Threat not found" }, { status: 404 });
    }

    return Response.json({ threat: result[0] });
  } catch (err) {
    console.error("PUT /api/threats/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const threatId = params.id;

    const result = await sql`
      DELETE FROM threat_detections 
      WHERE id = ${threatId} AND user_id = ${userId}
      RETURNING id
    `;

    if (result.length === 0) {
      return Response.json({ error: "Threat not found" }, { status: 404 });
    }

    return Response.json({ message: "Threat deleted successfully" });
  } catch (err) {
    console.error("DELETE /api/threats/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
