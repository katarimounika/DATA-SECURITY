import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get("limit")) || 50;
    const offset = parseInt(url.searchParams.get("offset")) || 0;
    const threatLevel = url.searchParams.get("threat_level");
    const status = url.searchParams.get("status");

    let whereClause = "WHERE user_id = $1";
    let params = [userId];
    let paramCount = 1;

    if (threatLevel) {
      paramCount++;
      whereClause += ` AND threat_level = $${paramCount}`;
      params.push(threatLevel);
    }

    if (status) {
      paramCount++;
      whereClause += ` AND status = $${paramCount}`;
      params.push(status);
    }

    const query = `
      SELECT id, threat_type, threat_level, confidence_score, source_data, 
             source_type, status, description, metadata, detected_at, resolved_at
      FROM threat_detections 
      ${whereClause}
      ORDER BY detected_at DESC 
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `;

    params.push(limit, offset);
    const threats = await sql(query, params);

    // Get total count
    const countQuery = `SELECT COUNT(*) as total FROM threat_detections ${whereClause}`;
    const countResult = await sql(countQuery, params.slice(0, -2)); // Remove limit and offset
    const total = parseInt(countResult[0]?.total || 0);

    return Response.json({ threats, total, limit, offset });
  } catch (err) {
    console.error("GET /api/threats error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const {
      threat_type,
      threat_level,
      confidence_score,
      source_data,
      source_type,
      description,
      metadata,
    } = body;

    // Validate required fields
    if (!threat_type || !threat_level || !confidence_score || !source_type) {
      return Response.json(
        {
          error:
            "Missing required fields: threat_type, threat_level, confidence_score, source_type",
        },
        { status: 400 },
      );
    }

    // Validate threat_level
    const validLevels = ["low", "medium", "high", "critical"];
    if (!validLevels.includes(threat_level)) {
      return Response.json(
        {
          error:
            "Invalid threat_level. Must be one of: " + validLevels.join(", "),
        },
        { status: 400 },
      );
    }

    // Validate source_type
    const validSources = ["email", "file", "url", "network"];
    if (!validSources.includes(source_type)) {
      return Response.json(
        {
          error:
            "Invalid source_type. Must be one of: " + validSources.join(", "),
        },
        { status: 400 },
      );
    }

    // Validate confidence_score
    if (confidence_score < 0 || confidence_score > 100) {
      return Response.json(
        {
          error: "confidence_score must be between 0 and 100",
        },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO threat_detections 
      (user_id, threat_type, threat_level, confidence_score, source_data, source_type, description, metadata)
      VALUES (${userId}, ${threat_type}, ${threat_level}, ${confidence_score}, ${source_data || null}, ${source_type}, ${description || null}, ${metadata ? JSON.stringify(metadata) : null})
      RETURNING id, threat_type, threat_level, confidence_score, source_data, source_type, status, description, metadata, detected_at
    `;

    const threat = result[0];

    // Create alert for high/critical threats
    if (threat_level === "high" || threat_level === "critical") {
      await sql`
        INSERT INTO alerts (user_id, threat_detection_id, alert_type, title, message, severity)
        VALUES (${userId}, ${threat.id}, 'threat_detection', 
                ${"DANGER!! " + (threat_level === "critical" ? "CRITICAL THREAT" : "HIGH THREAT") + " DETECTED"}, 
                ${"A " + threat_level + " level " + threat_type + " has been detected with " + confidence_score + "% confidence."}, 
                ${threat_level === "critical" ? "critical" : "danger"})
      `;
    }

    return Response.json({ threat }, { status: 201 });
  } catch (err) {
    console.error("POST /api/threats error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
