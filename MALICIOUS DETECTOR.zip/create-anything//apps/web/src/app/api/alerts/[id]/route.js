import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function PUT(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const alertId = params.id;
    const body = await request.json();
    const { is_read, is_dismissed } = body;

    const setClauses = [];
    const values = [];

    if (typeof is_read === "boolean") {
      setClauses.push("is_read = $" + (values.length + 1));
      values.push(is_read);
    }

    if (typeof is_dismissed === "boolean") {
      setClauses.push("is_dismissed = $" + (values.length + 1));
      values.push(is_dismissed);
    }

    if (setClauses.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    const query = `
      UPDATE alerts 
      SET ${setClauses.join(", ")}
      WHERE id = $${values.length + 1} AND user_id = $${values.length + 2}
      RETURNING id, alert_type, title, message, severity, is_read, is_dismissed, created_at
    `;

    const result = await sql(query, [...values, alertId, userId]);

    if (result.length === 0) {
      return Response.json({ error: "Alert not found" }, { status: 404 });
    }

    return Response.json({ alert: result[0] });
  } catch (err) {
    console.error("PUT /api/alerts/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const alertId = params.id;

    const result = await sql`
      DELETE FROM alerts 
      WHERE id = ${alertId} AND user_id = ${userId}
      RETURNING id
    `;

    if (result.length === 0) {
      return Response.json({ error: "Alert not found" }, { status: 404 });
    }

    return Response.json({ message: "Alert deleted successfully" });
  } catch (err) {
    console.error("DELETE /api/alerts/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
