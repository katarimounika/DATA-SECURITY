import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Get user data and profile
    const userRows = await sql`
      SELECT u.id, u.name, u.email, u.image, 
             p.phone, p.notification_preferences, p.security_settings
      FROM auth_users u
      LEFT JOIN user_profiles p ON u.id = p.user_id
      WHERE u.id = ${userId}
      LIMIT 1
    `;

    const user = userRows?.[0] || null;
    return Response.json({ user });
  } catch (err) {
    console.error("GET /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { phone, notification_preferences, security_settings } = body || {};

    // Check if profile exists
    const existingProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${userId} LIMIT 1
    `;

    if (existingProfile.length === 0) {
      // Create new profile
      await sql`
        INSERT INTO user_profiles (user_id, phone, notification_preferences, security_settings)
        VALUES (${userId}, ${phone || null}, ${notification_preferences || null}, ${security_settings || null})
      `;
    } else {
      // Update existing profile
      const setClauses = [];
      const values = [];

      if (typeof phone === "string") {
        setClauses.push("phone = $" + (values.length + 1));
        values.push(phone.trim() || null);
      }

      if (
        notification_preferences &&
        typeof notification_preferences === "object"
      ) {
        setClauses.push("notification_preferences = $" + (values.length + 1));
        values.push(JSON.stringify(notification_preferences));
      }

      if (security_settings && typeof security_settings === "object") {
        setClauses.push("security_settings = $" + (values.length + 1));
        values.push(JSON.stringify(security_settings));
      }

      setClauses.push("updated_at = NOW()");

      if (setClauses.length > 1) {
        // More than just updated_at
        const finalQuery = `UPDATE user_profiles SET ${setClauses.join(", ")} WHERE user_id = $${values.length + 1}`;
        await sql(finalQuery, [...values, userId]);
      }
    }

    // Return updated profile
    const updatedRows = await sql`
      SELECT u.id, u.name, u.email, u.image, 
             p.phone, p.notification_preferences, p.security_settings
      FROM auth_users u
      LEFT JOIN user_profiles p ON u.id = p.user_id
      WHERE u.id = ${userId}
      LIMIT 1
    `;

    const updated = updatedRows?.[0] || null;
    return Response.json({ user: updated });
  } catch (err) {
    console.error("PUT /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
