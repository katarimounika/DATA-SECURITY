import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const metricType = url.searchParams.get("metric_type");
    const limit = parseInt(url.searchParams.get("limit")) || 100;

    let whereClause = "";
    let params = [];

    if (metricType) {
      whereClause = "WHERE metric_type = $1";
      params.push(metricType);
    }

    const query = `
      SELECT metric_type, metric_value, unit, recorded_at
      FROM performance_metrics 
      ${whereClause}
      ORDER BY recorded_at DESC 
      LIMIT $${params.length + 1}
    `;

    params.push(limit);
    const metrics = await sql(query, params);

    // Get latest metrics summary
    const summaryMetrics = await sql`
      SELECT DISTINCT ON (metric_type) metric_type, metric_value, unit, recorded_at
      FROM performance_metrics 
      ORDER BY metric_type, recorded_at DESC
    `;

    return Response.json({ metrics, summary: summaryMetrics });
  } catch (err) {
    console.error("GET /api/performance error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { metric_type, metric_value, unit } = body;

    // Validate required fields
    if (!metric_type || metric_value === undefined || metric_value === null) {
      return Response.json(
        {
          error: "Missing required fields: metric_type, metric_value",
        },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO performance_metrics (metric_type, metric_value, unit)
      VALUES (${metric_type}, ${metric_value}, ${unit || null})
      RETURNING metric_type, metric_value, unit, recorded_at
    `;

    return Response.json({ metric: result[0] }, { status: 201 });
  } catch (err) {
    console.error("POST /api/performance error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
